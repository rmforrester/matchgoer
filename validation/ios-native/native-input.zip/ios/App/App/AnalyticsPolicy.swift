import Foundation

// SDK-independent gate, exercised with a recording sink; never logs payloads.
protocol AnalyticsSink: AnyObject {
    func configure() -> Bool
    func collection(_ enabled: Bool)
    func consent(_ accepted: Bool)
    func defaults(_ audience: String)
    func reset()
    func event(_ name: String, _ parameters: [String: String])
}

final class AnalyticsPolicy {
    typealias Rules = [String: [String: [String]]]
    private let sink: AnalyticsSink
    private let rules: Rules
    private let saveConsent: (String) -> Void
    private var savedConsent: String?
    private var generation = -1
    private var enabled = false

    init(sink: AnalyticsSink, rules: Rules, savedConsent: String? = nil,
         saveConsent: @escaping (String) -> Void = { _ in }) {
        self.sink = sink; self.rules = rules; self.savedConsent = savedConsent; self.saveConsent = saveConsent
    }

    @discardableResult
    func update(generation next: Int, consent choice: String, explicitConsent: Bool,
                audience: String?, pageAllowed: Bool) -> Bool {
        guard next > generation else { return enabled }
        generation = next; enabled = false
        sink.collection(false)
        if choice == "rejected" {
            savedConsent = choice; saveConsent(choice)
            // Reset local identifiers and unsent data; no claim of deleting already-uploaded data.
            sink.reset()
            sink.consent(false); sink.collection(false)
            return false
        }
        guard choice == "accepted", savedConsent != "rejected" || explicitConsent else { return false }
        savedConsent = choice; saveConsent(choice)
        guard let audience = audience, ["internal", "external", "unclassified"].contains(audience),
              pageAllowed, !rules.isEmpty, sink.configure() else { return false }
        // Default parameters apply to automatic app/session events too.
        sink.consent(true); sink.defaults(audience); sink.collection(true)
        enabled = true
        return true
    }

    @discardableResult
    func record(generation: Int, name: String, parameters: [String: Any]) -> Bool {
        guard enabled, generation == self.generation, name != "attendance_recorded",
              let allowed = rules[name] else { return false }
        var safe: [String: String] = [:]
        for (key, value) in parameters {
            if let value = value as? String, allowed[key]?.contains(value) == true { safe[key] = value }
        }
        // Native page_view must describe one of the approved page families.
        if name == "page_view", safe["page_location"] == nil { return false }
        sink.event(name, safe)
        return true
    }
}
