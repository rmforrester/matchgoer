import Foundation
import UIKit
import Capacitor
import CoreLocation

/// Foreground, one-shot location using the app identity; never WebKit geolocation.
@objc(MatchgoerLocationPlugin)
public final class MatchgoerLocationPlugin: CAPPlugin, CAPBridgedPlugin, CLLocationManagerDelegate {
    public let identifier = "MatchgoerLocationPlugin"
    public let jsName = "MatchgoerLocation"
    public let pluginMethods: [CAPPluginMethod] = [CAPPluginMethod(name: "getCurrentPosition", returnType: CAPPluginReturnPromise)]
    private var manager: CLLocationManager?
    private var calls: [CAPPluginCall] = []
    private var timeout: DispatchWorkItem?
    private var maximumAge: TimeInterval = 60
    private var timeoutSeconds: TimeInterval = 10
    private var started = Date()

    @objc func getCurrentPosition(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            guard UIApplication.shared.applicationState == .active else { call.reject("Location requires an active app", "POSITION_UNAVAILABLE"); return }
            self.calls.append(call)
            // Coalesce concurrent Discover requests, including while the OS prompt is open.
            guard self.calls.count == 1 else { return }
            self.maximumAge = max(0, call.getDouble("maximumAge") ?? 60000) / 1000
            self.timeoutSeconds = max(0.001, call.getDouble("timeout") ?? 10000) / 1000
            let manager = CLLocationManager()
            self.manager = manager
            manager.delegate = self
            manager.desiredAccuracy = call.getBool("enableHighAccuracy") == true ? kCLLocationAccuracyBest : kCLLocationAccuracyHundredMeters
            switch manager.authorizationStatus {
            case .notDetermined: manager.requestWhenInUseAuthorization()
            case .authorizedWhenInUse, .authorizedAlways: self.requestPosition()
            case .denied, .restricted: self.fail("PERMISSION_DENIED")
            @unknown default: self.fail("POSITION_UNAVAILABLE")
            }
        }
    }

    public func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        guard manager === self.manager, !calls.isEmpty else { return }
        switch manager.authorizationStatus {
        case .authorizedWhenInUse, .authorizedAlways: requestPosition()
        case .denied, .restricted: fail("PERMISSION_DENIED")
        default: break
        }
    }

    private func requestPosition() {
        guard let manager = manager, timeout == nil, !calls.isEmpty else { return }
        started = Date()
        if let cached = manager.location, maximumAge > 0, usable(cached), abs(cached.timestamp.timeIntervalSinceNow) <= maximumAge {
            finish(cached); return
        }
        // As with browser geolocation, acquisition timeout starts after authorization.
        let work = DispatchWorkItem { [weak self] in self?.fail("TIMEOUT") }
        timeout = work
        DispatchQueue.main.asyncAfter(deadline: .now() + timeoutSeconds, execute: work)
        manager.requestLocation()
    }

    private func usable(_ location: CLLocation) -> Bool {
        CLLocationCoordinate2DIsValid(location.coordinate) && location.horizontalAccuracy >= 0 && location.coordinate.latitude.isFinite && location.coordinate.longitude.isFinite
    }

    public func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard manager === self.manager, !calls.isEmpty else { return }
        guard let location = locations.last(where: { usable($0) && $0.timestamp >= started.addingTimeInterval(-maximumAge) }) else { return }
        finish(location)
    }

    public func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        guard manager === self.manager, !calls.isEmpty else { return }
        if let failure = error as? CLError, failure.code == .locationUnknown { return }
        fail(manager.authorizationStatus == .denied || manager.authorizationStatus == .restricted ? "PERMISSION_DENIED" : "POSITION_UNAVAILABLE")
    }

    private func takeCalls() -> [CAPPluginCall] {
        let pending = calls
        calls = []
        timeout?.cancel(); timeout = nil
        manager?.stopUpdatingLocation(); manager?.delegate = nil; manager = nil
        return pending
    }
    private func finish(_ location: CLLocation) {
        let value: [String: Any] = ["coords": ["latitude": location.coordinate.latitude, "longitude": location.coordinate.longitude, "accuracy": location.horizontalAccuracy], "timestamp": location.timestamp.timeIntervalSince1970 * 1000]
        for call in takeCalls() { call.resolve(value) }
    }
    private func fail(_ code: String) {
        for call in takeCalls() { call.reject("Location request could not complete", code) }
    }
}
