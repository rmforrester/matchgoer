import Foundation
import Capacitor
import FirebaseCore
import FirebaseAnalytics

private final class FirebaseAnalyticsSink: AnalyticsSink {
    private var configured = false
    func configure() -> Bool {
        if configured { return true }
        // No invented/default Firebase app, and no collection without a reviewed app config.
        guard let path = Bundle.main.path(forResource: "GoogleService-Info", ofType: "plist"),
              let values = NSDictionary(contentsOfFile: path),
              values["BUNDLE_ID"] as? String == "com.matchgoer.app",
              Bundle.main.bundleIdentifier == "com.matchgoer.app",
              let appID = values["GOOGLE_APP_ID"] as? String,
              appID.range(of: "^1:[0-9]+:ios:[0-9a-f]+$", options: .regularExpression) != nil,
              let sender = values["GCM_SENDER_ID"] as? String, appID.hasPrefix("1:" + sender + ":ios:"),
              let key = values["API_KEY"] as? String,
              key.range(of: "^A[A-Za-z0-9_-]{38}$", options: .regularExpression) != nil,
              let options = FirebaseOptions(contentsOfFile: path),
              options.projectID?.isEmpty == false else { return false }
        if let existing = FirebaseApp.app() {
            guard existing.options.googleAppID == options.googleAppID,
                  existing.options.projectID == options.projectID else { return false }
        } else { FirebaseApp.configure(options: options) }
        Analytics.setUserID(nil)
        configured = true
        return true
    }
    func collection(_ enabled: Bool) { Analytics.setAnalyticsCollectionEnabled(enabled) }
    func consent(_ accepted: Bool) {
        Analytics.setConsent([.analyticsStorage: accepted ? .granted : .denied,
                              .adStorage: .denied, .adUserData: .denied, .adPersonalization: .denied])
    }
    func defaults(_ audience: String) {
        var parameters: [String: Any] = ["audience_class": audience]
        if audience == "internal" { parameters["traffic_type"] = "internal" }
        else { parameters["traffic_type"] = NSNull() }
        Analytics.setDefaultEventParameters(nil)
        Analytics.setDefaultEventParameters(parameters)
    }
    func reset() { Analytics.resetAnalyticsData() }
    func event(_ name: String, _ parameters: [String: String]) { Analytics.logEvent(name, parameters: parameters) }
}

@objc(MatchgoerAnalyticsPlugin)
public final class MatchgoerAnalyticsPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "MatchgoerAnalyticsPlugin"
    public let jsName = "MatchgoerAnalytics"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "setState", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "logEvent", returnType: CAPPluginReturnPromise)
    ]
    private static let key = "matchgoer.analytics.native-consent.v1"
    private var policy: AnalyticsPolicy?

    // Called first in didFinishLaunching, before any Firebase configuration.
    // Overrides SDK collection enablement persisted by an earlier app execution.
    static func bootstrap() {
        Analytics.setAnalyticsCollectionEnabled(false)
    }

    public override func load() {
        Self.bootstrap()
        guard let path = Bundle.main.url(forResource: "native-analytics-rules", withExtension: "json"),
              let data = try? Data(contentsOf: path),
              let rules = try? JSONDecoder().decode(AnalyticsPolicy.Rules.self, from: data) else { return }
        policy = AnalyticsPolicy(sink: FirebaseAnalyticsSink(), rules: rules,
                                 savedConsent: UserDefaults.standard.string(forKey: Self.key),
                                 saveConsent: { UserDefaults.standard.set($0, forKey: Self.key) })
    }
    @objc func setState(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            let enabled = self.policy?.update(generation: call.getInt("generation") ?? -1,
                consent: call.getString("consent") ?? "unknown", explicitConsent: call.getBool("explicitConsent") ?? false,
                audience: call.getString("audience"), pageAllowed: call.getBool("pageAllowed") ?? false) ?? false
            call.resolve(["enabled": enabled])
        }
    }
    @objc func logEvent(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            let recorded = self.policy?.record(generation: call.getInt("generation") ?? -1,
                name: call.getString("name") ?? "", parameters: call.getObject("parameters") ?? [:]) ?? false
            call.resolve(["recorded": recorded])
        }
    }
}
